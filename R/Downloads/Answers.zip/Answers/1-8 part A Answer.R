{
  rm(list=ls()); options(show.error.locations = TRUE);  

  # Get the temperature from the user
  userTemp = readline("What was the temperature? ");
  userTemp = as.numeric(userTemp);

  # The if-else-if structure goes from the coldest temperature to the
  # hottest temperature.  The is because the if-else-if structure is
  # mutually exclusive -- only one codeblock will be executed.  So even
  # though a temperature of -40 would cause the condition (userTemp < 30)
  # to be TRUE, the condition will never be check because the first 
  # condition (userTemp <= -20) has already be determined to be TRUE
  # and the codeblock attached to this condition is the only one that
  # will be executed
  
  # check if temp is less than or equal to -20
  if(userTemp <= -20)
  {
    cat("Invalid Temperature -- too low");
  }
  # check if temp is less than 30 (but temps <= -20 have already been excluded by the above condition)
  else if(userTemp < 30)
  {
    cat("Cold!");
  }
  # check if temp is equal to 30 
  else if(userTemp == 30)
  {
    cat("Cold-ish");
  }
  # check if temp is less than 60 (but temps <= 30 have already been excluded by the above conditions)
  else if(userTemp < 60)
  {
    cat("Warm");
  }
  # check if temp is equal to 60
  else if(userTemp == 60)
  {
    cat("Hot-ish");
  } 
  # check if temp is less than or equal to 100 (but temps <= 60 have already been excluded by the above conditions)
  else if(userTemp <= 100)
  {
    cat("Hot");
  } 
  # all temperature not covered by above conditions (so temps > 100)
  else
  {
    cat("Invalid Temperature -- too high")
  }
  
  # Remember that no more than one codeblock can be executed in an
  # if-else-if structure
}