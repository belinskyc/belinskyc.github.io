{
  rm(list=ls());  options(show.error.locations = TRUE);
  
  #### Part 1
  # Function that makes multiple conversions-- it takes 3 parameters:
  #   weight: The weight value to convert
  #   unitTo: the unit to convert the value to
  #   unitFrom: the unit the value has
  
  weightConversion = function(weight, unitTo, unitFrom)
  {
    if(unitTo == "grams" && unitFrom == "kilograms")
    {
      conversion = weight*1000;
    }
    else if(unitTo == "grams" && unitFrom == "pounds")
    {
      conversion = weight*(453.592);
    }
    else if(unitTo == "kilograms" && unitFrom == "grams")
    {
      conversion = weight/1000;
    }
    else if(unitTo == "kilograms" && unitFrom == "pounds")
    {
      conversion = weight*(0.453592);
    }
    else if (unitTo == "pounds" && unitFrom == "grams")
    {
      conversion = weight*(.0022);
    }
    else if (unitTo == "pounds" && unitFrom == "kilograms")
    {
      conversion = weight*(2.20462);
    }
    return (conversion);
  } 
  
  weightConversion1 = weightConversion(4, "grams" , "kilograms")
  weightConversion2 = weightConversion(1000, "kilograms", "grams")
  weightConversion3 = weightConversion(4, "grams", "pounds" )
  weightConversion4 = weightConversion(20, "pounds", "grams")
  weightConversion5 = weightConversion(20, "kilograms", "pounds")
  weightConversion6 = weightConversion(20, "pounds", "kilograms" )
  
  
  ### Part 2
 
  tempDifference = function(dailyTemps)
  {
    dailyTempDifference = c();

    for(i in 2:length(dailyTemps))
    {
      dailyTempDifference[i-1] = dailyTemps[i]-dailyTemps[i-1];
    }
    
    return (dailyTempDifference);
  }
  
  tempDiff1 = tempDifference(c(40,45,35,42));
}
